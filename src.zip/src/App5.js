import React,{Component} from 'react';
class App5 extends React.Component{
    constructor(){
        super();
        this.state={num:0}
        this.incrementNumber=this.incrementNumber.bind(this);
    }
    incrementNumber(){
        this.setState({num:this.state.num+2})
    }
    render(){
        return(
            <div>
            

            <h3><Num1 newNum={this.state.num} updateNumber={this.incrementNumber}></Num1></h3>
            </div>
        )
    }
}
class Num1 extends React.Component{
    constructor(){
        super();
        
    }

    render(){
        return(
            <div>
                <button onClick={this.props.updateNumber}>Increment Number</button>
                <h4>{this.props.newNum}</h4>
            </div>
        )
    }
}
export default App5;