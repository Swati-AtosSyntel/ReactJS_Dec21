import React,{Component} from 'react';
import RaectDOM from 'react-dom';
class App7 extends React.Component{
    render(){
        const list=['Red','Blue','Green','Black'];
        const list1=list.map((color,index)=>
            <li key={index}>{color}</li>);
        return(
            <div>
                <ul>
                    {list1}
                </ul>
            </div>
            );
        
    }
}
export default App7;