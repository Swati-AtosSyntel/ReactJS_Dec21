import React,{Component} from 'react';

class ControlledReactForm1 extends React.Component{
    constructor(){
        super();
        this.state={value:""};
        this.handleSubmit=this.handleSubmit.bind(this);
        this.handleChange=this.handleChange.bind(this);
    }
    handleChange(event){
        this.setState({value:event.target.value});
    }
    handleSubmit(event){
        alert("Submiited value is:"+this.state.value);
        event.preventDefault();
    }
    render(){
        return(
            <div>
            <h3>Controlled React Form</h3>
            <form onSubmit={this.handleSubmit}>
                    <input type="text" value={this.state.value} onChange={this.handleChange}/>
                    <input type="submit" value="Submit"/>
            </form>
            </div>
        )
    }
}
export default ControlledReactForm1;