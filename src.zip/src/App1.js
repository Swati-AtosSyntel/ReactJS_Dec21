import React,{Component} from 'react';
import App from './App';
import App2 from './App2';
import App3 from './App3';
import App4 from './App4';
import App5 from './App5';
import App6 from './App6';
import App7 from './App7';
import App9 from './App9';
import ControlledReactForm1 from './reactform1';
import UnControlledReactForm1 from './reactForm2';
import Greeting from './conditionalrender';
import CountMe from './ReactUseStateHook';
import MyName from './ReactUseStateHook1';
import Counter from './RaectUseReducer';
import Users from './CustomHook';
class App1 extends React.Component{
    constructor(){
        super();
        this.state={data:
        [{id:123,firstname:'Nishant',lastname:"Mishra"},
        {id:124,firstname:'Nishant',lastname:"Mishra"},
        {id:125,firstname:'Nishant',lastname:"Mishra"}]
    };
    }
    render(){
        return <div>
            <h1>Hi {this.props.name} !!!!</h1>
            <h3>{this.state.firstname}</h3>
            {/* <App name="Pradeep"/>
            <App/> */}
            {/* <App2/>
            <App3/>
            <App4/>
            <App5/>
            <App6/> */}
            <App9/>
            <hr/>
            <ControlledReactForm1/>
            <hr/>
            <UnControlledReactForm1/>
            <Greeting isloggedIn={true}/>
            <CountMe/>
            <MyName/>
            <Counter/>
            <Users/>
            <hr/><br/>

            <table border="1">
                <tr>
                    <th>Employee ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                </tr>
                <tbody>
            {this.state.data.map((person)=>
            <TableData empid={person.id} 
            fname={person.firstname} 
            lname={person.lastname}/>)}
            </tbody>
            </table>
            </div>
    }
}
class TableData extends React.Component{
    render(){
        return(
            
                <tr>
                    <td>{this.props.empid}</td>
                    <td>{this.props.fname}</td>
                    <td>{this.props.lname}</td>
                </tr>
            
        )
    }
}
export default App1;