import React,{Component,useState,useEffect} from 'react';

function App9(){
    const[count,setCount]=useState(0);
    const [location,setLocation]=useState("");
    
    const incrementCount=()=>setCount(count+2);
    useEffect(()=>{
        document.title=`You clicked ${count} times`;
        console.log(location);
        
    },[count,location]);
//     useEffect(()=>{
//         console.log(location);
//     },[location])
//    // useDocumentTitle('You clicked  ${count} times');
    return(
        <div>
            <p>You clicked {count} times</p>
            <button onClick={incrementCount}>Click Here</button>
            <button onClick={()=>setLocation("Pune")}>Update Location</button>
            <p>{location}</p>
        </div>
    )

    

}
export default App9;