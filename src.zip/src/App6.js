import React,{Component} from 'react';
import { ReactDOM } from 'react';
class App6 extends React.Component{
    constructor(){
        super();
        this.Ref1=React.createRef();
        this.setFoucsTo=this.setFoucsTo.bind(this);
    }
    setFoucsTo(){
        this.Ref1.current.focus();
    }
    render(){
        return (
            <div>
            <input type="text" ref={this.Ref1}/>
            <button onClick={this.setFoucsTo}>Add Text</button>
            </div>
            )
            
    }
}
export default App6;