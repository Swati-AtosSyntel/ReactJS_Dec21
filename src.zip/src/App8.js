import React,{Component,useState} from 'react';
import useDocumentTitle from '@rehooks/document-title';
function App8(){
    const[count,setCount]=useState(0);
    const incrementCount=()=>setCount(count+2);

   // useDocumentTitle('You clicked  ${count} times');
    return(
        <div>
            <p>You clicked {count} times</p>
            <button onClick={incrementCount}>Click Here</button>
        </div>
    )

    

}
export default App8;