import React,{Component} from 'react';

function LoggedInUser(props){
    return <h2>Welcome {props.username}</h2>
}
function GuestUsers(props){
    return <h2>Welcome Guest User!!!! To get full access, please sign up</h2>
}

function Greeting(props){
    const isloggedIn=props.isloggedIn;

    if(isloggedIn){
        return <LoggedInUser username="Swati"/>;

    }
    return <GuestUsers/>;
}
export default Greeting;