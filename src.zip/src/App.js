import React,{Component} from 'react';
import logo from './logo.svg';
import './App.css';

function App(props) {
  return (
    <div>
          
    <h1>Hi {props.name},This is React Application 1</h1>    
      
    </div>
  );
}
App.defaultProps={
  name:"React"
}
export default App;
