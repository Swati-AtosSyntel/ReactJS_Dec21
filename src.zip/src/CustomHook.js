import useFetchData from "./useFetchData";

function Users(){
    const {data}=useFetchData("https://api.github.com/users");

    return(
        <div>
            {data && (
                data.map((user)=>(
                    <div key={user.id}>
                        <h3>{user.login}</h3>
                        <h3>{user.type}</h3>
                    </div>
                ))
            )}
        </div>
    )
}
export default Users;