import React,{Component} from 'react';

class UnControlledReactForm1 extends React.Component{
    constructor(){
        super();
        this.input=React.createRef();
        this.HandleSubmit=this.HandleSubmit.bind(this);
    }
    HandleSubmit(event){
        alert("Submitted value is :"+this.input.current.value);
    }
    render(){
        return(
            <div>
            <h3>UnControlled React Form</h3>
            <form onSubmit={this.HandleSubmit}>
                    <input type="text" ref={this.input}/>
                    <input type="submit" value="Submit"/>
            </form>
            </div>
        )
    }
}
export default UnControlledReactForm1;