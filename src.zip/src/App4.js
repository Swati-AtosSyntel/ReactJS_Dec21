import React,{Component} from 'react';
import ReactDom from 'react-dom';
class App4 extends  React.Component{
    constructor(){
        super();
        this.updateDivtextColor=this.updateDivtextColor.bind(this);
    }
    updateDivtextColor(){
        var divElement=document.getElementById('div1');
        ReactDom.findDOMNode(divElement).style.color='blue';
    }
    render(){
        return(
            <div>
                <button onClick={this.updateDivtextColor}>Update Text Color</button>
                <div id="div1">First Child DIV element</div>
            </div>
        )
    }
}
export default App4;