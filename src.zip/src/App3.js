import React,{Component} from 'react';
class App3 extends React.Component{
    constructor(){
        super();
        this.forceUpdateNumber=this.forceUpdateNumber.bind(this);
    }
    forceUpdateNumber(){
        this.forceUpdate();
    }
    render(){
        return(
            <div>
                <h4>Number: {Math.random()}</h4>
                <button onClick={this.forceUpdateNumber}>Click here to get random number</button>
            </div>
        )
    }
}
export default App3;