import React,{Component} from 'react';
class App2 extends React.Component{
    constructor(){
        super();
        this.state={num:0}
        this.incrementNumber=this.incrementNumber.bind(this);
    }
    incrementNumber(){
        this.setState({num:this.state.num+2})
    }
    render(){
        return(
            <div>
            <button onClick={this.incrementNumber}>Increment Number</button>

            <h3><Num newNum={this.state.num}></Num></h3>
            </div>
        )
    }
}
class Num extends React.Component{
    constructor(){
        super();
        console.log('constructor called');
    }
    componentWillMount(){
        console.log('Component will mount');
    }
    componentDidMount(){
        console.log('component did mount');
    }
    componentWillReceiveProps(newProps){
        console.log('component will receive props');
    }
    shouldComponentUpdate(newProps,newState){
        return true;
    }
    componentWillUpdate(newxtProps,nextState){
        console.log('Component will update');
    }
    componentDidUpdate(prevProps,prevState){
        console.log('componet did update');
    }
    render(){
        return(
            <div>
                <h4>{this.props.newNum}</h4>
            </div>
        )
    }
}
export default App2;