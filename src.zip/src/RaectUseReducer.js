import React,{useReducer} from  'react';
import { StateContext } from 'rehooks';

const initialState={count:0};
function reducer(state,action){
switch(action){
    case 'increment':
        return{count:state.count+1};
    case 'decrement':
        return {count:state.count-1};
    default:
        throw new Error();
}
}

function Counter()
{
    const [state,dispatch]=useReducer(reducer,initialState);
    return(
        <div>
        Count:{state.count}
        <button onClick={()=>dispatch({type:'decrement'})}>Decrease the count</button>
        <button onClick={()=>dispatch({type:'increment'})}>Increase the count</button>
        </div>
    )
}

export default Counter;