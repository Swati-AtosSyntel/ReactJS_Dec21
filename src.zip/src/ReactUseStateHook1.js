import React,{useState} from 'react';

function MyName(){
    const [name,setName]=useState("");
    return(
        <div>
            <form>
                <input type="text" value={name} onChange={(e)=>setName(e.target.value)}/>
                <p>{name}</p>
            </form>
        </div>
    )
}

export default MyName;